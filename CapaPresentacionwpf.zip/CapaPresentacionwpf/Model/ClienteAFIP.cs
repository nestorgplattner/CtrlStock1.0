﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaPresentacionwpf.Model
{
    public class ClienteAFIP
    {
        public string CUIT { get; set; }
        public string Nombre { get; set; }
        public string Domicilio { get; set; }
        public string CondicionIVA { get; set; }
    }
}
