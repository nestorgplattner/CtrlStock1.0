﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaPresentacionWPF.Model
{
    public class ComprobanteSimple
    {
        public int IdComprobante { get; set; }
        public string Tipo { get; set; }
        
    }
}

